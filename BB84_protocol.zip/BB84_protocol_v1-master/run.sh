#!/bin/sh

python3 Alice.py &
python3 Bob.py & 
